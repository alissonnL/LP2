﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        double num1 = 0;
        double num2 = 0;

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtboxNum1.Text = String.Empty;
            txtboxNum2.Text = String.Empty;
            txtboxResultado.Text = String.Empty;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtboxNum2_TextChanged(object sender, EventArgs e)
        {
            if (txtboxNum2.Text.Length >= 1)
                num2 = Double.Parse(txtboxNum2.Text);
            else
                num2 = 0;
        }

        private void txtboxNum1_TextChanged(object sender, EventArgs e)
        {

            if (txtboxNum1.Text.Length >= 1)
                num1 = Double.Parse(txtboxNum1.Text);
            else
                num1 = 0;
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Enter))
            {
                SendKeys.Send("{TAB}");
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            txtboxResultado.Text = (num1 + num2).ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Não é possível fazer divisão por zero.\n" +
                    "Digite um número diferente de 0 no campo \"Numero 2\".");
            }
            else
            {
                txtboxResultado.Text = (num1 / num2).ToString();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            txtboxResultado.Text = (num1 - num2).ToString();
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            txtboxResultado.Text = (num1 * num2).ToString();
        }

        private void txtboxNum1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
    }
}
