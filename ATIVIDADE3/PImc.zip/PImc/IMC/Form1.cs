﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double altura;
        double peso;
        double imc;

        

        String classificacao(double imc)
        {

            if (imc < 18.5)
                return "MAGREZA";
            else if (imc <= 24.9)
                return "NORMAL";
            else if (imc <= 29.9)
                return "SOBREPESO";
            else if (imc <= 39.9)
                return "OBESIDADE";
            else
                return "OBESIDADE GRAVE";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtIMC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtAltura.Text.Replace(".", ","), out altura));
            else
                altura = 0;

            if (Double.TryParse(txtPeso.Text.Replace(".", ","), out peso));
            else
                peso = 0;


            if (peso > 0 && altura > 0)
            {
                imc = Math.Round(peso / Math.Pow(altura, 2), 1);
                txtIMC.Text = "IMC: " + imc.ToString() + " ::: " + classificacao(imc);
            }
            else
                MessageBox.Show("Digite números maiores que 0.");

        }

        private void lblIMC_Click(object sender, EventArgs e)
        {

        }

       
       
    }
}
