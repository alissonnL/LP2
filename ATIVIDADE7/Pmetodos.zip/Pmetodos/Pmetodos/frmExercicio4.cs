﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumericos_Click(object sender, EventArgs e)
        {
            int count = 0;
            for(int i = 0; i < rtxtTexto.TextLength; i++)
            {
                if(rtxtTexto.Text.Substring(i, 1).All(Char.IsNumber))
                {
                    count++;
                }
            }
            MessageBox.Show("Existem " + count + " caracteres numéricos no texto");
        }

        private void btnWhiteSpace_Click(object sender, EventArgs e)
        {
            int index = 0;
            while(!rtxtTexto.Text.Substring(index, 1).All(Char.IsWhiteSpace))
            {
                index++;
            }
            MessageBox.Show("O primeiro caracter em branco está na posição " + (index + 1));
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int count = 0;
            foreach(var i in rtxtTexto.Text)
            {
                if (char.IsLetter(i))
                {
                    count++;
                }
            }
            MessageBox.Show("No texto há " + count + " caracteres alfabéticos");
        }
    }
}
