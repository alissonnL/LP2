﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int num1;
            int num2;

            if(!int.TryParse(txtNumero1.Text, out num1)){
                MessageBox.Show("Digite um inteiro válido");
            }
            if(!int.TryParse(txtNumero2.Text, out num2) || num1 > num2)
            {
                MessageBox.Show("Digite um inteiro válido");
            }else
                MessageBox.Show("O número sorteado foi: " + rnd.Next(num1, num2));

        }
    }
}
