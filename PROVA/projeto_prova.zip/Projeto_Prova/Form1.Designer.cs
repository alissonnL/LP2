﻿namespace Projeto_Prova
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExec = new System.Windows.Forms.Button();
            this.lstbxTimes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnExec
            // 
            this.btnExec.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExec.Location = new System.Drawing.Point(111, 154);
            this.btnExec.Name = "btnExec";
            this.btnExec.Size = new System.Drawing.Size(112, 100);
            this.btnExec.TabIndex = 0;
            this.btnExec.Text = "Executar";
            this.btnExec.UseVisualStyleBackColor = true;
            this.btnExec.Click += new System.EventHandler(this.btnExec_Click);
            // 
            // lstbxTimes
            // 
            this.lstbxTimes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstbxTimes.FormattingEnabled = true;
            this.lstbxTimes.ItemHeight = 16;
            this.lstbxTimes.Location = new System.Drawing.Point(325, 64);
            this.lstbxTimes.Name = "lstbxTimes";
            this.lstbxTimes.Size = new System.Drawing.Size(394, 276);
            this.lstbxTimes.TabIndex = 1;
            this.lstbxTimes.SelectedIndexChanged += new System.EventHandler(this.lstbxTimes_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 440);
            this.Controls.Add(this.lstbxTimes);
            this.Controls.Add(this.btnExec);
            this.Name = "Form1";
            this.Text = "Prova";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExec;
        private System.Windows.Forms.ListBox lstbxTimes;
    }
}

