﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Projeto_Prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lstbxTimes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            int[,] times = new int[7, 3];
            int golFeitos = 0;
            int golRecebidos = 0;
            for (int i = 0; i < 7; i++)
            {
                for (int index = 0; index < 2; index++)
                {
                    string gols = Interaction.InputBox("Número de gols " + (index == 0? "feitos" : "recebidos") + " do time:" + (i + 1), "Entrada de dados");
                    if(!int.TryParse(gols, out times[i, index])){
                        MessageBox.Show("Digite um inteiro válido");
                        index--;
                    }
                    else if (times[i, index] < 0)
                    {
                        MessageBox.Show("Digite um número maior que zero!");
                        index--;
                    }
                }
                golFeitos += times[i, 0];
                golRecebidos += times[i, 1];
                
                times[i, 2] = times[i, 0] - times[i, 1];
                lstbxTimes.Items.Add("Time:" + (i + 1) + " Gols feitos:" + times[i, 0] + " Gols recebidos:" + times[i, 1] + " Saldo de gols:" + times[i, 2]);
            }
            lstbxTimes.Items.Add("---------------------------------------------");
            lstbxTimes.Items.Add("Total gols feitos:" + golFeitos);
            lstbxTimes.Items.Add("Total gols recebidos:" + golRecebidos);

        }
    }
}
