﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void testeTriangulo()
        {
            try
            {

                if (txtA.Text != String.Empty && txtB.Text != String.Empty && txtC.Text != String.Empty)
                {
                    double A = Double.Parse(txtA.Text);
                    double B = Double.Parse(txtB.Text);
                    double C = Double.Parse(txtC.Text);

                    if ((Math.Abs(B - C) < A && A < B + C) || (Math.Abs(A - C) < B && B < A + C) || (Math.Abs(A - B) < C && C < A + B))
                    {
                        if (A != B && A != C && B != C)
                            txtResultado.Text = "Triângulo Escaleno";
                        else if (A == B && B == C && A == C)
                            txtResultado.Text = "Triângulo Equilátero";
                        else if ((A == B) || (A == C) || (B == C))
                            txtResultado.Text = "Triângulo Isósceles";
                    }
                    else
                        MessageBox.Show("Medidas não formam um triângulo");
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            testeTriangulo();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtResultado.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
