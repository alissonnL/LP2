﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rbtnFeminino_CheckedChanged(object sender, EventArgs e)
        {

        }

        private double INSS()
        {
            double result = 0;
            double bruto;
            double.TryParse(mskbxSalBruto.Text, out bruto);

            if(bruto <= (double)800.47)
            {
                result = bruto * (double)0.0765;
                mskbxINSS.Text = "7.65%";
            }
            else if(bruto <= (double)1050)
            {
                result = bruto * (double)0.0865;
                mskbxINSS.Text = "8.65%";
            }
            else if(bruto <= (double)1400.77)
            {
                result = bruto * (double)0.09;
                mskbxINSS.Text = "9.00%";
            }
            else if(bruto <= (double)2801.56)
            {
                result = bruto * (double)0.11;
                mskbxINSS.Text = "11.00%";
            }
            else
            {
                result = (double)308.17;
                mskbxINSS.Text = "Teto";
            }

            return result;
        }
        
        private double IRPF()
        {
            double result = 0;
            double bruto;
            double.TryParse(mskbxSalBruto.Text, out bruto);

            if (bruto > (double)1257.12 && bruto <= (double)2512.08)
            {
                mskbxIRPF.Text = "15.00%";
                result = bruto * (double)0.15;
            }
            else if (bruto > (double)2512.08)
            {
                mskbxIRPF.Text = "27.5%";
                result = bruto * (double)0.275;
            }
            else
            {
                mskbxIRPF.Text = "0,00";
            }

            return result;
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double salBruto;

            double qtdFilhos = decimal.ToDouble(nudQtdFilhos.Value);
            
            if(txtNome.Text != String.Empty)
            {
                if(double.TryParse(mskbxSalBruto.Text, out salBruto))
                {
                    string sexo;
                    mskbxDescINSS.Text = INSS().ToString("F");
                    mskbxDescIRPF.Text = IRPF().ToString("F");

                        if (mskbxSalBruto.Text != String.Empty)
                        {
                                if (salBruto <= (double)435.52)
                                {
                                    mskbxSalFamilia.Text = (22.33 * qtdFilhos).ToString();
                                }
                                else if (salBruto <= (double)654.61)
                                {
                                    mskbxSalFamilia.Text = (15.74 * qtdFilhos).ToString();
                                }
                                else
                                {
                                    mskbxSalFamilia.Text = "0,00";
                                }
                            mskbxSalLiquido.Text = (salBruto - INSS() - IRPF() + double.Parse(mskbxSalFamilia.Text)).ToString("F");
                        }

                    if (rbtnFeminino.Checked)
                        sexo = "Sra.";
                    else
                    {
                        sexo = "Sr.";
                    }

                    lblDados.Text = "Os descontos " + (rbtnFeminino.Checked ? "da Sra. " : "do Sr. ") + txtNome.Text +
                        $" que é {(ckbxEC.Checked? "casado(a)": "solteiro(a)")} e que tem {qtdFilhos} filhos(as).";
                   
                }
                else
                {
                    MessageBox.Show("Digite um valor válido para o salário bruto.");
                }
            }
            else
            {
                MessageBox.Show("Digite o nome do funcionário");
            }

        }

        private void mskbxDescINSS_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
