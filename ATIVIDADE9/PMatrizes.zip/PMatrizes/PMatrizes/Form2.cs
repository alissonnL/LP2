﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[7];
            int[] vNomes = new int[7];

            for (int i = 0; i < 7; i++)
            {
             nomes[i] = Interaction.InputBox("Digite um nome", "Entrada de dados");
                vNomes[i] = nomes[i].Replace(" ", "").Length;
            }
            foreach(var element in nomes)
            {
                lstbNomes.Items.Add($"o nome:{element} tem {vNomes[Array.IndexOf(nomes, element)]} caracteres");
            }
        }
    }
}
