﻿
namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnMercadoria = new System.Windows.Forms.Button();
            this.btnSomaChar = new System.Windows.Forms.Button();
            this.btnPrintAlunos = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnAt6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInverter
            // 
            this.btnInverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverter.Location = new System.Drawing.Point(33, 31);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(148, 74);
            this.btnInverter.TabIndex = 0;
            this.btnInverter.Text = "Inverter valores";
            this.btnInverter.UseVisualStyleBackColor = true;
            this.btnInverter.Click += new System.EventHandler(this.btnInverter_Click);
            // 
            // btnMercadoria
            // 
            this.btnMercadoria.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMercadoria.Location = new System.Drawing.Point(207, 31);
            this.btnMercadoria.Name = "btnMercadoria";
            this.btnMercadoria.Size = new System.Drawing.Size(148, 74);
            this.btnMercadoria.TabIndex = 1;
            this.btnMercadoria.Text = "Ler Mercadorias";
            this.btnMercadoria.UseVisualStyleBackColor = true;
            this.btnMercadoria.Click += new System.EventHandler(this.btnMercadoria_Click);
            // 
            // btnSomaChar
            // 
            this.btnSomaChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomaChar.Location = new System.Drawing.Point(388, 31);
            this.btnSomaChar.Name = "btnSomaChar";
            this.btnSomaChar.Size = new System.Drawing.Size(148, 74);
            this.btnSomaChar.TabIndex = 2;
            this.btnSomaChar.Text = "Soma char Alunos";
            this.btnSomaChar.UseVisualStyleBackColor = true;
            this.btnSomaChar.Click += new System.EventHandler(this.btnSomaChar_Click);
            // 
            // btnPrintAlunos
            // 
            this.btnPrintAlunos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintAlunos.Location = new System.Drawing.Point(568, 31);
            this.btnPrintAlunos.Name = "btnPrintAlunos";
            this.btnPrintAlunos.Size = new System.Drawing.Size(148, 74);
            this.btnPrintAlunos.TabIndex = 3;
            this.btnPrintAlunos.Text = "Array Alunos";
            this.btnPrintAlunos.UseVisualStyleBackColor = true;
            this.btnPrintAlunos.Click += new System.EventHandler(this.btnPrintAlunos_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedia.Location = new System.Drawing.Point(33, 148);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(148, 74);
            this.btnMedia.TabIndex = 4;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnAt6
            // 
            this.btnAt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAt6.Location = new System.Drawing.Point(207, 148);
            this.btnAt6.Name = "btnAt6";
            this.btnAt6.Size = new System.Drawing.Size(148, 74);
            this.btnAt6.TabIndex = 5;
            this.btnAt6.Text = "Atividade 6";
            this.btnAt6.UseVisualStyleBackColor = true;
            this.btnAt6.Click += new System.EventHandler(this.btnAt6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 397);
            this.Controls.Add(this.btnAt6);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnPrintAlunos);
            this.Controls.Add(this.btnSomaChar);
            this.Controls.Add(this.btnMercadoria);
            this.Controls.Add(this.btnInverter);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnMercadoria;
        private System.Windows.Forms.Button btnSomaChar;
        private System.Windows.Forms.Button btnPrintAlunos;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnAt6;
    }
}

